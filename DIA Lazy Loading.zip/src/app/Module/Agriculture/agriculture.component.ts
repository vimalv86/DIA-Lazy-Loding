import { Component } from '@angular/core';

@Component({
    selector: 'agriculture',
    templateUrl: './agriculture.component.html',
    styleUrls: ['./agriculture.component.scss']
})

export class AgricultureComponent {
    
}
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

// Components
import { SmeComponent } from './sme.component';
import { SmeLandingComponent } from './Landing/landing.component';

// Routing
import { SmeRoutes } from './sme.routing';

@NgModule({
  declarations: [
    SmeComponent,
    SmeLandingComponent
  ],
  imports: [
    RouterModule.forChild(SmeRoutes)
  ],
  providers: [],
  bootstrap: [SmeComponent]
})
export class SmeModule { 
  
}

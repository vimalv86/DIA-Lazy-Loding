import { Routes } from '@angular/router';
import { SmeLandingComponent } from './Landing/landing.component';

export const SmeRoutes: Routes = [
  {
    path: '',
    component: SmeLandingComponent
  },
  {
    path: 'Presanction',
    loadChildren: './Landing/Pre Sanction/presanction.module#SmePresanctionModule'
  }
];
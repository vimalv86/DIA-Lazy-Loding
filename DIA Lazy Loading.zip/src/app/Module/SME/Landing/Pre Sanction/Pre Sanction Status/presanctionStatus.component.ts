import { Component } from '@angular/core';

@Component({
    selector: 'sme-presanction-status',
    templateUrl: './presanctionStatus.component.html',
    styleUrls: ['./presanctionStatus.component.scss', '../../../../module.component.scss']
})

export class SmePresanctionStatusComponent {
    
}
import { Routes } from '@angular/router';
import { SmePresanctionComponent } from './presanction.component';
import { SmePresanctionInspectionComponent } from './Inspection/inspection.component';
import { SmePresanctionSearchComponent } from './Pre Sanction Search/presanctionSearch.component';
import { SmePresanctionIncompleteComponent } from './Pre Sanction Incomplete/presanctionIncomplete.component';
import { SmePresanctionStatusComponent } from './Pre Sanction Status/presanctionStatus.component';

export const presanctionRoutes: Routes = [
  {
    path: '',
    component: SmePresanctionComponent,
    children: [
      {
        path: 'Inspection',
        component: SmePresanctionInspectionComponent,
        children: [
          {
            path: 'New',
            component: SmePresanctionSearchComponent
          },
          {
            path: 'Incomplete',
            component: SmePresanctionIncompleteComponent
          },
          {
            path: 'Status',
            component: SmePresanctionStatusComponent
          },
          {
            path: '',
            redirectTo: 'New',
            pathMatch: 'full'
          }
        ]
      },
      {
        path: '',
        redirectTo: 'Inspection',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: 'Presanction',
    pathMatch: 'full'
  }
];
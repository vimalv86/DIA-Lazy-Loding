import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sme-inspection',
  templateUrl: './inspection.component.html',
  styleUrls: ['./inspection.component.scss', '../presanction.component.scss', '../../../../module.component.scss']
})

export class SmePresanctionInspectionComponent implements OnInit {
  private breadcrumbItems: any;
  private submenuItems: any;
  ngOnInit() {
    console.log("SmePresanctionInspectionComponent");

    this.breadcrumbItems = [
      { label: 'Home' },
      { label: 'Pre Sanction Inspection' }
    ];

    this.submenuItems = [
      {
        label: 'New',
        url: '/Sme/Presanction/Inspection/New'
      },
      {
        label: 'Incomplete',
        url: '/Sme/Presanction/Inspection/Incomplete'
      },
      {
        label: 'Inspection Status',
        url: '/Sme/Presanction/Inspection/Status'
      }
    ];
  }
}
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'sme-presanction',
    templateUrl: './presanction.component.html',
    styleUrls: ['./presanction.component.scss']
})

export class SmePresanctionComponent implements OnInit {
  ngOnInit() {
    console.log("Hai");
  }  
}
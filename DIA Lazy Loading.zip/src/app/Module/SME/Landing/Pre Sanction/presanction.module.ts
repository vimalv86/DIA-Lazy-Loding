import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

//Module Components
import { SmePresanctionComponent } from './presanction.component';
import { SmePresanctionInspectionComponent } from './Inspection/inspection.component';
import { SmePresanctionSearchComponent } from './Pre Sanction Search/presanctionSearch.component';
import { SmePresanctionIncompleteComponent } from './Pre Sanction Incomplete/presanctionIncomplete.component';
import { SmePresanctionStatusComponent } from './Pre Sanction Status/presanctionStatus.component';

//Libraries
import { 
  ButtonModule,
  BreadcrumbModule,
  RadioButtonModule,
  InputTextModule,
  CalendarModule,
  MessageModule,
  //TableModule
} from 'primeng/primeng';
import { TableModule } from 'primeng/table'

//Routing
import { presanctionRoutes } from './presanction.routing';

//Services
import { SmePresanctionIncompleteService } from '../../../../Service/Module/SME/Pre Sanction/Incomplete/incomplete.service';

@NgModule({
  declarations: [
    SmePresanctionComponent,
    SmePresanctionInspectionComponent,
    SmePresanctionSearchComponent,
    SmePresanctionIncompleteComponent,
    SmePresanctionStatusComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(presanctionRoutes),
    ButtonModule,
    BreadcrumbModule,
    RadioButtonModule,
    InputTextModule,
    CalendarModule,
    MessageModule,
    TableModule
  ],
  providers: [
    SmePresanctionIncompleteService
  ],
  bootstrap: [SmePresanctionComponent]
})
export class SmePresanctionModule { }

import { Component, OnInit } from '@angular/core';

//Services
import { SmePresanctionIncompleteService } from '../../../../../Service/Module/SME/Pre Sanction/Incomplete/incomplete.service';

@Component({
  selector: 'sme-presanction-incomplete',
  templateUrl: './presanctionIncomplete.component.html',
  styleUrls: ['./presanctionIncomplete.component.scss', '../../../../module.component.scss'],
  providers: [
    SmePresanctionIncompleteService
  ]
})

export class SmePresanctionIncompleteComponent implements OnInit {
  private apiRequest: Object;
  private incompleteList: any;

  constructor(
    private smePresanctionIncompleteService: SmePresanctionIncompleteService
  ) { }

  ngOnInit() {

    this.apiRequest = { "appId": "WEB-DIA", "executivePFIndex": 1100024 };
    this.smePresanctionIncompleteService.getSmePresanctionIncomplete(this.apiRequest).subscribe(response=>{
      if (response.incompleteList) {
        this.incompleteList = response.incompleteList; // Complete data of Incomplete List

        for(let i=0; i<this.incompleteList.length; i++) { // Adding a space for WebIncomplete & MobIncomplete
          if(this.incompleteList[i].loanStatus == 'WebIncomplete') {
            this.incompleteList[i].loanStatus = 'Web Incomplete'
          }
          if(this.incompleteList[i].loanStatus == 'MobIncomplete') {
            this.incompleteList[i].loanStatus = 'Mob Incomplete'
          }
        }

      }
    });
  }
}
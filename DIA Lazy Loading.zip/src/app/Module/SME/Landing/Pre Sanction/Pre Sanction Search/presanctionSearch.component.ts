import { Component, OnInit } from '@angular/core';
import { BreadcrumbModule } from 'primeng/primeng';

@Component({
    selector: 'sme-presanction-search',
    templateUrl: './presanctionSearch.component.html',
    styleUrls: ['./presanctionSearch.component.scss', '../presanction.component.scss', '../../../../module.component.scss']
})

export class SmePresanctionSearchComponent implements OnInit {

  ngOnInit() {

    console.log("search");
    
    
  }
    
}
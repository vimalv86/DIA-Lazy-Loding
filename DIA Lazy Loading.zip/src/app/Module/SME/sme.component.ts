import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'sme',
    templateUrl: './sme.component.html',
    styleUrls: ['./sme.component.scss']
})

export class SmeComponent implements OnInit {
  private breadcrumbItems: any;
  ngOnInit() {
    console.log("Hai");
    
    this.breadcrumbItems = [
        {label:'Categories'},
        {label:'Sports'},
        {label:'Football'},
        {label:'Countries'},
        {label:'Spain'},
        {label:'F.C. Barcelona'},
        {label:'Squad'},
        {label:'Lionel Messi', url: 'https://en.wikipedia.org/wiki/Lionel_Messi'}
    ];
  }
}
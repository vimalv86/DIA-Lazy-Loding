import { Component } from '@angular/core';

@Component({
    selector: 'cag',
    templateUrl: './cag.component.html',
    styleUrls: ['./cag.component.scss']
})

export class CagComponent {
    
}
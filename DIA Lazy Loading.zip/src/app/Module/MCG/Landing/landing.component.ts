import { Component } from '@angular/core';

@Component({
    selector: 'mcg-landing',
    templateUrl: './landing.component.html',
    styleUrls: ['./landing.component.scss', '../../module.component.scss']
})

export class McgLandingComponent {
    
}
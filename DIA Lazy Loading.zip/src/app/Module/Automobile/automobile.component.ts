import { Component } from '@angular/core';

@Component({
    selector: 'automobile',
    templateUrl: './automobile.component.html',
    styleUrls: ['./automobile.component.scss']
})

export class AutomobileComponent {
    
}
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { HttpModule, Http, RequestOptions, XHRBackend } from '@angular/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';

//Libraries
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { 
  ButtonModule,
  MessageModule,
  BreadcrumbModule,
  InputTextModule,
  CalendarModule
} from 'primeng/primeng';

//Common Components
import { HeaderComponent } from './Component/Header/header.component';
import { HeaderNavigationComponent } from './Component/HeaderNavigation/headerNavigation.component';
import { FooterComponent } from './Component/Footer/footer.component';

//Module Components
 import { McgComponent } from './Module/MCG/mcg.component';
 import { McgLandingComponent } from './Module/MCG/Landing/landing.component';

//Routing
import { routes } from './app.routing';

//Spinner
import { HttpService } from './Core/http.service';
import { HttpFactory } from './Core/http.factory';
import { SpinnerComponent } from './Component/Spinner/spinner.component';

@NgModule({
  declarations: [
    AppComponent,
    SpinnerComponent,
    HeaderComponent,
    HeaderNavigationComponent,
    FooterComponent,
    McgComponent,
    McgLandingComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes),
    HttpModule, 
    AngularFontAwesomeModule,
    ButtonModule,
    MessageModule,
    BreadcrumbModule,
    InputTextModule,
    CalendarModule
  ],
  providers: [
    {
      provide: Http, useFactory: HttpFactory,
      deps: [XHRBackend, RequestOptions]
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

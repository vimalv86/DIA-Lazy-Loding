import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { DIAConfig } from '../../../Shared/Config/config';

@Injectable()
export class UserInfoService {
  private url = DIAConfig.pfIdUrl;
  constructor(private http: Http) { }
  public getUserInfo(data: any): Observable<any> {
    return this.http.post(this.url, data, null)
      .map(response => {
        let result: any = response.json();
        return result;
      })
      .catch(response => {
        return "Error";
      });
  }
}
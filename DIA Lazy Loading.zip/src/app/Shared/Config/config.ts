export class DIAConfig {
  /* For AWS Server */
  public static apiUrl:string = "http://sbi-706173083.us-west-2.elb.amazonaws.com/dia";
  public static pfIdUrl: string = "http://35.165.144.114:8080/UmService/getPfId";
  /* -------------------------------------------------------------------------------------- */
}
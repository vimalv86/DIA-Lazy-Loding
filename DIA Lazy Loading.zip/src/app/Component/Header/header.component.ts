import { Component, OnInit } from '@angular/core';

import { UserInfoService } from '../../Service/User/UserInfo/userInfo.service';

@Component({
  selector: 'dia-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [
    UserInfoService
  ]
})
export class HeaderComponent implements OnInit {
  private apiRequest: Object;
  private pfId: Number;
  private userInfo: Object;

  constructor(
    private userInfoService: UserInfoService
  ) { }

  ngOnInit() {
    this.pfId = 1100024;
    this.apiRequest = { "pfId": this.pfId, "invokedFrom": "login"};
    this.userInfoService.getUserInfo(this.apiRequest).subscribe(response => {
      if (response && response.responseCode == 200) {
        if(response.userDetails && response.userDetails.role == 4) {
          this.userInfo = response;
        } else {
          console.log("error");
        }
      }
    })
  }
}

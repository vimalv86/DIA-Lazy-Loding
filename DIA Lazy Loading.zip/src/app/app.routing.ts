import { Routes } from '@angular/router';
import { SmeComponent } from './Module/SME/sme.component';
import { McgComponent } from './Module/MCG/mcg.component';
import { SmeModule} from './Module/SME/sme.module'

export const routes: Routes = [
  {
    path: 'Sme',
    loadChildren: './Module/SME/sme.module#SmeModule'
  },
  {
    path: 'Mcg',
    component: McgComponent
  },
  {
    path: '',
    redirectTo: 'Sme',
    pathMatch: 'full'
  }
];
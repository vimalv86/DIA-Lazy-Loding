import { Injectable } from '@angular/core';
import {
  Http,
  XHRBackend,
  Request,
  RequestOptions,
  RequestOptionsArgs,
  Response,
  Headers
} from '@angular/http';
import { Observable } from 'rxjs/Rx';


@Injectable()
export class HttpService extends Http {
  public pendingRequests: number = 0;
  public showLoading: boolean = false;
  private isNotification: boolean = false;

  constructor(backend: XHRBackend, defaultOptions: RequestOptions) {
    super(backend, defaultOptions);
  }

  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
    return this.intercept(super.request(url, options));
  }

  get(url: string, options?: RequestOptionsArgs): Observable<Response> {
    return this.intercept(super.get(url, options));
  }

  post(url: string, body: string, options?: RequestOptionsArgs): Observable<Response> {
    if (url.indexOf("/dia/getnotifications") !== -1) {
      this.isNotification = true;
    } else {
      this.isNotification = false;
    }
    return this.intercept(super.post(url, body));
  }

  getRequestOptionArgs(options?: RequestOptionsArgs): RequestOptionsArgs {
    if (options === null) {
      options = new RequestOptions();
    }
    if (options.headers === null) {
      options.headers = new Headers();
      options.headers.append('Content-Type', 'application/json');
    }
    return options;
  }

  intercept(observable: Observable<Response>): Observable<Response> {
    if (!this.isNotification) {
      this.turnOnModal();
    }

    this.pendingRequests++;
    return observable
      .catch((err, source) => {
        if (err.status === 401) {  
          return Observable.empty();
        } else {
          return Observable.throw(err);
        }
      })
      .do((res: Response) => {
      }, (err: any) => {
        this.turnOffModal();
      })
      .finally(() => {
        var timer = Observable.timer(100);
        timer.subscribe(t => {
          this.turnOffModal();
        });
      });
  }

  private turnOnModal() {
    if (!this.showLoading) {
      this.showLoading = true;
      document.querySelector("#spinner-wrapper").className = 'show';
    }
    this.showLoading = true;
  }

  private turnOffModal() {
    this.pendingRequests--;
    if (this.pendingRequests <= 0) {
      if (this.showLoading) {
        document.querySelector("#spinner-wrapper").className = 'hide';
      }
      this.showLoading = false;
    }
  }
}

